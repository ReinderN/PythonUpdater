import time


def main(version):
    while True:
        time.sleep(.5)
        print(version)
